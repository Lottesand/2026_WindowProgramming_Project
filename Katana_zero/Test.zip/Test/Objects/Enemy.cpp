﻿#include "Enemy.h"
#include "Player.h"
#include "Physics.h"
#include "../SceneAndMap/Camera.h"
#include "../Effects/EffectManager.h"
#include <gdiplus.h>
#include <map>

Enemy::Enemy(float startX, float startY, EnemyType type, float patrolRange) {
    m_startX = startX; m_startY = startY; m_x = startX; m_y = startY;
    m_vx = 2.0f; m_vy = 0.0f; m_colW = 40.0f; m_colH = 60.0f;
    m_isAlive = true; m_isFacingLeft = false; m_Type = type; m_State = EnemyState::ES_IDLE;
    m_CurrentFrame = 0; m_LastTime = GetTickCount(); m_friction = 0.94f; m_knockbackVx = 0.0f;
    m_isImmortal = false; m_patternTimer = GetTickCount(); m_isWaiting = false; m_walkDistance = 0.0f;
    m_detectionRange = 200.0f; m_isPlayerDetected = false; m_patrolRange = patrolRange;
    m_bloodDistance = 0.0f;
}
Enemy::~Enemy() {}

void Enemy::CheckPlayerDetection(const Player& player) {
    if (!m_isAlive) { m_isPlayerDetected = false; return; }
    float px = player.GetX() + player.GetColW() / 2.0f, py = player.GetY() + player.GetColH() / 2.0f;
    float ex = m_x + m_colW / 2.0f, ey = m_y + m_colH / 2.0f;
    float dx = (float)fabs(px - ex), dy = (float)fabs(py - ey);
    m_isPlayerDetected = (dx <= m_detectionRange && dy <= 50.0f);
}

void Enemy::RenderDebug(HDC hdc, float camX, float camY, float mapScale) {
    int sx = (int)((m_x - camX) * mapScale), sy = (int)((m_y - camY) * mapScale);
    HBRUSH redBrush = CreateSolidBrush(RGB(255, 0, 0));
    RECT rect = { sx, sy, sx + (int)(m_colW * mapScale), sy + (int)(m_colH * mapScale) };
    FrameRect(hdc, &rect, redBrush); DeleteObject(redBrush);
    COLORREF dc = m_isPlayerDetected ? RGB(255, 0, 0) : RGB(150, 0, 0);
    HPEN hP = CreatePen(PS_SOLID, m_isPlayerDetected ? 3 : 1, dc); HPEN hOP = (HPEN)SelectObject(hdc, hP);
    int r = (int)(m_detectionRange * mapScale), cx = sx + (int)(m_colW * mapScale / 2), cy = sy + (int)(m_colH * mapScale / 2);
    MoveToEx(hdc, cx - r, cy, NULL); LineTo(hdc, cx + r, cy);
    SelectObject(hdc, hOP); DeleteObject(hP);
}

void Enemy::ReleaseAll() { Gangster::Release(); Grunt::Release(); Pomp::Release(); ShieldCop::Release(); }

void Enemy::Reset() {
    m_x = m_startX; m_y = m_startY; m_vx = 2.0f; m_vy = 0.0f; m_isAlive = true; m_isFacingLeft = false; m_State = EnemyState::ES_IDLE;
    m_CurrentFrame = 0; m_LastTime = GetTickCount(); m_knockbackVx = 0.0f; m_patternTimer = GetTickCount(); m_isWaiting = false; m_walkDistance = 0.0f; m_isPlayerDetected = false;
    m_bloodDistance = 0.0f;
}

void Enemy::OnTakeDamage(float kvx, float kvy) { if (!m_isImmortal) { m_isAlive = false; m_State = EnemyState::ES_DEAD; m_vx = kvx; m_vy = kvy; m_CurrentFrame = 0; m_bloodDistance = 0.0f; } }
void Enemy::ApplyKnockback(float vx) { m_knockbackVx = vx; m_vx = vx; }

void Enemy::Update(float ts, const Player& player) {
    if (m_vx != 0.0f) { 
        float nx = m_x + m_vx * ts; 
        if (!CheckMapCollision(nx, m_y, m_colW, m_colH)) {
            if (!m_isAlive) {
                m_bloodDistance += (float)fabs(m_vx * ts);
                if (m_bloodDistance >= 25.0f) {
                    m_bloodDistance -= 25.0f;
                    float length = sqrt(m_vx * m_vx + m_vy * m_vy);
                    if (length > 0) {
                        float nvx = m_vx / length;
                        float nvy = m_vy / length;
                        float perpX1 = -nvy;
                        float perpY1 = nvx;
                        float perpX2 = nvy;
                        float perpY2 = -nvx;
                        float angle1 = atan2(perpY1, perpX1);
                        float angle2 = atan2(perpY2, perpX2);
                        
                        float speed1 = 2.0f + (rand() % 30) / 10.0f;
                        float speed2 = 2.0f + (rand() % 30) / 10.0f;
                        EffectManager::AddBloodSplatter(m_x + m_colW / 2.0f, m_y + m_colH / 2.0f, perpX1 * speed1 + ((rand() % 100) / 100.0f - 0.5f), perpY1 * speed1 + ((rand() % 100) / 100.0f - 0.5f), angle1, GetTickCount());
                        EffectManager::AddBloodSplatter(m_x + m_colW / 2.0f, m_y + m_colH / 2.0f, perpX2 * speed2 + ((rand() % 100) / 100.0f - 0.5f), perpY2 * speed2 + ((rand() % 100) / 100.0f - 0.5f), angle2, GetTickCount());
                    }
                }
            }
            m_x = nx; 
        } else m_vx = 0.0f; 
        if (!m_isAlive) m_vx *= m_friction; 
    }
    float gravity = m_isAlive ? 2.0f : 1.2f;
    m_vy += gravity * ts; if (m_vy > 30.0f) m_vy = 30.0f;
    float nextY = m_y + m_vy; bool landed = false;
    auto cf = [&](float ty) { int tl = GetCollisionType((int)(m_x + 2.0f), (int)(ty + m_colH)), tc = GetCollisionType((int)(m_x + m_colW / 2.0f), (int)(ty + m_colH)), tr = GetCollisionType((int)(m_x + m_colW - 2.0f), (int)(ty + m_colH)); if (tl == 1 || tl == 3 || tc == 1 || tc == 3 || tr == 1 || tr == 3) return true; if (tl == 2 || tc == 2 || tr == 2) { if (m_y + m_colH <= ty + m_colH) return true; } return false; };
    if (m_vy > 0) { for (float sy = m_y; sy <= nextY; sy += 1.0f) { if (cf(sy)) { m_y = sy; landed = true; break; } } if (landed) m_vy = 0; else m_y = nextY; }
    else if (m_vy < 0) { auto cc = [&](float ty) { int tl = GetCollisionType((int)(m_x + 2.0f), (int)ty), tc = GetCollisionType((int)(m_x + m_colW / 2.0f), (int)ty), tr = GetCollisionType((int)(m_x + m_colW - 2.0f), (int)ty); return (tl == 1 || tl == 3 || tc == 1 || tc == 3 || tr == 1 || tr == 3); }; bool hc = false; for (float sy = m_y; sy >= nextY; sy -= 1.0f) { if (cc(sy)) { m_y = sy; hc = true; break; } } if (hc) m_vy = 0; else m_y = nextY; }
    else m_y = nextY;
}

// Gangster
CImage Gangster::m_ImgIdle_R[8], Gangster::m_ImgIdle_L[8], Gangster::m_ImgWalk_R[8], Gangster::m_ImgWalk_L[8], Gangster::m_ImgAim_R[7], Gangster::m_ImgAim_L[7], Gangster::m_ImgFire_R[6], Gangster::m_ImgFire_L[6], Gangster::m_ImgTurn_R[6], Gangster::m_ImgTurn_L[6], Gangster::m_ImgFall_R[12], Gangster::m_ImgFall_L[12], Gangster::m_ImgHurtFly_R[2], Gangster::m_ImgHurtFly_L[2], Gangster::m_ImgHurtGround_R[14], Gangster::m_ImgHurtGround_L[14], Gangster::m_ImgRun_R[10], Gangster::m_ImgRun_L[10];
Gangster::Gangster(float x, float y) : Enemy(x, y, EnemyType::GANGSTER) { m_ActionState = GangsterAction::GA_NONE; }
Gangster::~Gangster() {}
void Gangster::Reset() { Enemy::Reset(); m_ActionState = GangsterAction::GA_NONE; }
void Gangster::OnTakeDamage(float kvx, float kvy) { if (m_isImmortal) return; Enemy::OnTakeDamage(kvx, kvy); m_ActionState = GangsterAction::GA_HURT_FLY; }
void Gangster::Init() { if (!m_ImgIdle_R[0].IsNull()) return; TCHAR path[256]; for (int i = 0; i < 8; i++) { wsprintf(path, TEXT("assets/enemy/spr_gangsteridle/%d.png"), i); m_ImgIdle_R[i].Load(path); m_ImgIdle_L[i].Load(path); } for (int i = 0; i < 8; i++) { wsprintf(path, TEXT("assets/enemy/spr_gangsterwalk/%d.png"), i); m_ImgWalk_R[i].Load(path); m_ImgWalk_L[i].Load(path); } for (int i = 0; i < 7; i++) { wsprintf(path, TEXT("assets/enemy/spr_gangster_aim/%d.png"), i); m_ImgAim_R[i].Load(path); m_ImgAim_L[i].Load(path); } for (int i = 0; i < 6; i++) { wsprintf(path, TEXT("assets/enemy/spr_fire_1/%d.png"), i); m_ImgFire_R[i].Load(path); m_ImgFire_L[i].Load(path); } for (int i = 0; i < 6; i++) { wsprintf(path, TEXT("assets/enemy/spr_gangsterturn/%d.png"), i); m_ImgTurn_R[i].Load(path); m_ImgTurn_L[i].Load(path); } for (int i = 0; i < 12; i++) { wsprintf(path, TEXT("assets/enemy/spr_gangsterfall/%d.png"), i); m_ImgFall_R[i].Load(path); m_ImgFall_L[i].Load(path); } for (int i = 0; i < 2; i++) { wsprintf(path, TEXT("assets/enemy/spr_gangsterhurtfly/%d.png"), i); m_ImgHurtFly_R[i].Load(path); m_ImgHurtFly_L[i].Load(path); } for (int i = 0; i < 14; i++) { wsprintf(path, TEXT("assets/enemy/spr_gangsterhurtground/%d.png"), i); m_ImgHurtGround_R[i].Load(path); m_ImgHurtGround_L[i].Load(path); } for (int i = 0; i < 10; i++) { wsprintf(path, TEXT("assets/enemy/spr_gangsterrun/%d.png"), i); m_ImgRun_R[i].Load(path); m_ImgRun_L[i].Load(path); } }
void Gangster::Release() { for (int i = 0; i < 8; i++) { m_ImgIdle_R[i].Destroy(); m_ImgIdle_L[i].Destroy(); } for (int i = 0; i < 8; i++) { m_ImgWalk_R[i].Destroy(); m_ImgWalk_L[i].Destroy(); } for (int i = 0; i < 7; i++) { m_ImgAim_R[i].Destroy(); m_ImgAim_L[i].Destroy(); } for (int i = 0; i < 6; i++) { m_ImgFire_R[i].Destroy(); m_ImgFire_L[i].Destroy(); } for (int i = 0; i < 6; i++) { m_ImgTurn_R[i].Destroy(); m_ImgTurn_L[i].Destroy(); } for (int i = 0; i < 12; i++) { m_ImgFall_R[i].Destroy(); m_ImgFall_L[i].Destroy(); } for (int i = 0; i < 2; i++) { m_ImgHurtFly_R[i].Destroy(); m_ImgHurtFly_L[i].Destroy(); } for (int i = 0; i < 14; i++) { m_ImgHurtGround_R[i].Destroy(); m_ImgHurtGround_L[i].Destroy(); } for (int i = 0; i < 10; i++) { m_ImgRun_R[i].Destroy(); m_ImgRun_L[i].Destroy(); } }
void Gangster::Update(float ts, const Player& player) {
    CheckPlayerDetection(player); Enemy::Update(ts, player);
    if (!m_isAlive) { if (m_ActionState == GangsterAction::GA_HURT_FLY && m_vy == 0) { m_ActionState = GangsterAction::GA_HURT_GROUND; m_vx = 0; m_CurrentFrame = 0; } if (GetTickCount() - m_LastTime >= 100) { if (m_ActionState == GangsterAction::GA_HURT_GROUND) { if (m_CurrentFrame < 13) m_CurrentFrame++; } else m_CurrentFrame++; m_LastTime = GetTickCount(); } return; }
    if (m_isWaiting) { m_vx = 0.0f; m_State = EnemyState::ES_IDLE; if (GetTickCount() - m_patternTimer >= 2000) { m_isWaiting = false; m_patternTimer = GetTickCount(); m_walkDistance = 0.0f; m_isFacingLeft = !m_isFacingLeft; m_vx = m_isFacingLeft ? -2.0f : 2.0f; } }
    else { m_State = EnemyState::ES_WALK; float nx = m_x + m_vx * ts; if (!CheckMapCollision(nx, m_y, m_colW, m_colH)) { m_x = nx; m_walkDistance += (float)fabs(m_vx * ts); m_isFacingLeft = (m_vx < 0.0f); if (m_walkDistance >= m_patrolRange) { m_isWaiting = true; m_patternTimer = GetTickCount(); } } else { m_isWaiting = true; m_patternTimer = GetTickCount(); } }
    if (m_vy > 0.1f) m_State = EnemyState::ES_FALL; if (GetTickCount() - m_LastTime > 100) { m_CurrentFrame++; m_LastTime = GetTickCount(); }
}
void Gangster::Render(HDC hdc, Gdiplus::Graphics* g, float camX, float camY, float mapScale, bool showDebugRect, bool isSlowMo) {
    if (!m_isAlive && m_ActionState != GangsterAction::GA_HURT_FLY && m_ActionState != GangsterAction::GA_HURT_GROUND) return;
    int sx = (int)((m_x - camX) * mapScale), sy = (int)((m_y - camY) * mapScale);
    float es = 1.8f, msX = 1.0f, msY = 1.0f; CImage* img = nullptr;
    if (m_isFacingLeft) { if (m_ActionState == GangsterAction::GA_HURT_FLY) img = &m_ImgHurtFly_L[m_CurrentFrame % 2]; else if (m_ActionState == GangsterAction::GA_HURT_GROUND || m_State == EnemyState::ES_DEAD) img = &m_ImgHurtGround_L[m_CurrentFrame % 14]; else if (m_State == EnemyState::ES_FALL) img = &m_ImgFall_L[m_CurrentFrame % 12]; else if (m_State == EnemyState::ES_IDLE) { img = &m_ImgIdle_L[m_CurrentFrame % 8]; msX = 1.1f; msY = 1.1f; } else if (m_State == EnemyState::ES_WALK) img = &m_ImgWalk_L[m_CurrentFrame % 8]; }
    else { if (m_ActionState == GangsterAction::GA_HURT_FLY) img = &m_ImgHurtFly_R[m_CurrentFrame % 2]; else if (m_ActionState == GangsterAction::GA_HURT_GROUND || m_State == EnemyState::ES_DEAD) img = &m_ImgHurtGround_R[m_CurrentFrame % 14]; else if (m_State == EnemyState::ES_FALL) img = &m_ImgFall_R[m_CurrentFrame % 12]; else if (m_State == EnemyState::ES_IDLE) { img = &m_ImgIdle_R[m_CurrentFrame % 8]; msX = 1.1f; msY = 1.1f; } else if (m_State == EnemyState::ES_WALK) img = &m_ImgWalk_R[m_CurrentFrame % 8]; }
    if (img && !img->IsNull()) {
        int fw = (int)(img->GetWidth() * es * msX * mapScale), fh = (int)(img->GetHeight() * es * msY * mapScale);
        int fy = sy + (int)(m_colH * mapScale) - fh, dx = sx + (int)(m_colW * mapScale / 2) - (fw / 2);
        if (!isSlowMo && !m_isFacingLeft) { img->Draw(hdc, dx, fy, fw, fh); }
        else {
            if (img->IsDIBSection()) {
                void* bits = img->GetBits(); if (bits) {
                    Gdiplus::Bitmap b(img->GetWidth(), img->GetHeight(), img->GetPitch(), PixelFormat32bppARGB, (BYTE*)bits);
                    if (m_isFacingLeft) { g->ScaleTransform(-1.0f, 1.0f); g->TranslateTransform(-(float)(dx * 2 + fw), 0); }
                    if (isSlowMo) {
                        Gdiplus::ImageAttributes na; Gdiplus::ColorMatrix nm = {0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,1,0, 1,0,1,0,1}; na.SetColorMatrix(&nm);
                        int off = (int)(2 * mapScale);
                        g->DrawImage(&b, Gdiplus::Rect(dx - off, fy, fw, fh), 0, 0, img->GetWidth(), img->GetHeight(), Gdiplus::UnitPixel, &na);
                        g->DrawImage(&b, Gdiplus::Rect(dx + off, fy, fw, fh), 0, 0, img->GetWidth(), img->GetHeight(), Gdiplus::UnitPixel, &na);
                        g->DrawImage(&b, Gdiplus::Rect(dx, fy - off, fw, fh), 0, 0, img->GetWidth(), img->GetHeight(), Gdiplus::UnitPixel, &na);
                        g->DrawImage(&b, Gdiplus::Rect(dx, fy + off, fw, fh), 0, 0, img->GetWidth(), img->GetHeight(), Gdiplus::UnitPixel, &na);
                        Gdiplus::ImageAttributes ba; Gdiplus::ColorMatrix bm = {0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,1,0, 0,0,0,0,1}; ba.SetColorMatrix(&bm);
                        g->DrawImage(&b, Gdiplus::Rect(dx, fy, fw, fh), 0, 0, img->GetWidth(), img->GetHeight(), Gdiplus::UnitPixel, &ba);
                    } else g->DrawImage(&b, Gdiplus::Rect(dx, fy, fw, fh));
                    if (m_isFacingLeft) g->ResetTransform();
                }
            } else {
                img->Draw(hdc, dx, fy, fw, fh);
            }
        }
    }
    if (showDebugRect) RenderDebug(hdc, camX, camY, mapScale);
}

// Grunt
CImage Grunt::m_ImgIdle_R[8], Grunt::m_ImgIdle_L[8], Grunt::m_ImgWalk_R[10], Grunt::m_ImgWalk_L[10], Grunt::m_ImgAttack_R[8], Grunt::m_ImgAttack_L[8], Grunt::m_ImgSlash_R[5], Grunt::m_ImgSlash_L[5], Grunt::m_ImgTurn_R[8], Grunt::m_ImgTurn_L[8], Grunt::m_ImgFall_R[13], Grunt::m_ImgFall_L[13], Grunt::m_ImgHurtFly_R[2], Grunt::m_ImgHurtFly_L[2], Grunt::m_ImgHurtGround_R[16], Grunt::m_ImgHurtGround_L[16], Grunt::m_ImgRun_R[10], Grunt::m_ImgRun_L[10];
Grunt::Grunt(float x, float y) : Enemy(x, y, EnemyType::GRUNT) { m_ActionState = GruntAction::GR_NONE; }
Grunt::~Grunt() {}
void Grunt::Reset() { Enemy::Reset(); m_ActionState = GruntAction::GR_NONE; }
void Grunt::OnTakeDamage(float kvx, float kvy) { if (m_isImmortal) return; Enemy::OnTakeDamage(kvx, kvy); m_ActionState = GruntAction::GR_HURT_FLY; }
void Grunt::Init() { if (!m_ImgIdle_R[0].IsNull()) return; TCHAR path[256]; for (int i = 0; i < 8; i++) { wsprintf(path, TEXT("assets/enemy/spr_grunt_idle/%d.png"), i); m_ImgIdle_R[i].Load(path); m_ImgIdle_L[i].Load(path); } for (int i = 0; i < 10; i++) { wsprintf(path, TEXT("assets/enemy/spr_grunt_walk/%d.png"), i); m_ImgWalk_R[i].Load(path); m_ImgWalk_L[i].Load(path); } for (int i = 0; i < 8; i++) { wsprintf(path, TEXT("assets/enemy/spr_grunt_attack/%d.png"), i); m_ImgAttack_R[i].Load(path); m_ImgAttack_L[i].Load(path); } for (int i = 0; i < 5; i++) { wsprintf(path, TEXT("assets/enemy/spr_gruntslash/%d.png"), i); m_ImgSlash_R[i].Load(path); m_ImgSlash_L[i].Load(path); } for (int i = 0; i < 8; i++) { wsprintf(path, TEXT("assets/enemy/spr_grunt_turn/%d.png"), i); m_ImgTurn_R[i].Load(path); m_ImgTurn_L[i].Load(path); } for (int i = 0; i < 13; i++) { wsprintf(path, TEXT("assets/enemy/spr_grunt_fall/%d.png"), i); m_ImgFall_R[i].Load(path); m_ImgFall_L[i].Load(path); } for (int i = 0; i < 2; i++) { wsprintf(path, TEXT("assets/enemy/spr_grunt_hurtfly/%d.png"), i); m_ImgHurtFly_R[i].Load(path); m_ImgHurtFly_L[i].Load(path); } for (int i = 0; i < 16; i++) { wsprintf(path, TEXT("assets/enemy/spr_grunt_hurtground/%d.png"), i); m_ImgHurtGround_R[i].Load(path); m_ImgHurtGround_L[i].Load(path); } for (int i = 0; i < 10; i++) { wsprintf(path, TEXT("assets/enemy/spr_grunt_run/%d.png"), i); m_ImgRun_R[i].Load(path); m_ImgRun_L[i].Load(path); } }
void Grunt::Release() { for (int i = 0; i < 8; i++) { m_ImgIdle_R[i].Destroy(); m_ImgIdle_L[i].Destroy(); } for (int i = 0; i < 10; i++) { m_ImgWalk_R[i].Destroy(); m_ImgWalk_L[i].Destroy(); } for (int i = 0; i < 8; i++) { m_ImgAttack_R[i].Destroy(); m_ImgAttack_L[i].Destroy(); } for (int i = 0; i < 5; i++) { m_ImgSlash_R[i].Destroy(); m_ImgSlash_L[i].Destroy(); } for (int i = 0; i < 8; i++) { m_ImgTurn_R[i].Destroy(); m_ImgTurn_L[i].Destroy(); } for (int i = 0; i < 13; i++) { m_ImgFall_R[i].Destroy(); m_ImgFall_L[i].Destroy(); } for (int i = 0; i < 2; i++) { m_ImgHurtFly_R[i].Destroy(); m_ImgHurtFly_L[i].Destroy(); } for (int i = 0; i < 16; i++) { m_ImgHurtGround_R[i].Destroy(); m_ImgHurtGround_L[i].Destroy(); } for (int i = 0; i < 10; i++) { m_ImgRun_R[i].Destroy(); m_ImgRun_L[i].Destroy(); } }
void Grunt::Update(float ts, const Player& player) {
    CheckPlayerDetection(player); Enemy::Update(ts, player);
    if (!m_isAlive) { if (m_ActionState == GruntAction::GR_HURT_FLY && m_vy == 0) { m_ActionState = GruntAction::GR_HURT_GROUND; m_vx = 0; m_CurrentFrame = 0; } if (GetTickCount() - m_LastTime >= 100) { if (m_ActionState == GruntAction::GR_HURT_GROUND) { if (m_CurrentFrame < 15) m_CurrentFrame++; } else m_CurrentFrame++; m_LastTime = GetTickCount(); } return; }
    if (m_isWaiting) { m_vx = 0.0f; m_State = EnemyState::ES_IDLE; if (GetTickCount() - m_patternTimer >= 1500) { m_isWaiting = false; m_patternTimer = GetTickCount(); m_isFacingLeft = !m_isFacingLeft; m_vx = m_isFacingLeft ? -2.5f : 2.5f; } }
    else { m_State = EnemyState::ES_WALK; float nx = m_x + m_vx * ts; bool oor = (m_isFacingLeft && nx < m_startX - m_patrolRange / 2.0f) || (!m_isFacingLeft && nx > m_startX + m_patrolRange / 2.0f); if (!CheckMapCollision(nx, m_y, m_colW, m_colH) && !oor) { m_x = nx; m_isFacingLeft = (m_vx < 0.0f); } else { m_isWaiting = true; m_patternTimer = GetTickCount(); } }
    if (m_vy > 0.1f) m_State = EnemyState::ES_FALL; if (GetTickCount() - m_LastTime > 100) { m_CurrentFrame++; m_LastTime = GetTickCount(); }
}
void Grunt::Render(HDC hdc, Gdiplus::Graphics* g, float camX, float camY, float mapScale, bool showDebugRect, bool isSlowMo) {
    if (!m_isAlive && m_ActionState != GruntAction::GR_HURT_FLY && m_ActionState != GruntAction::GR_HURT_GROUND) return;
    int sx = (int)((m_x - camX) * mapScale), sy = (int)((m_y - camY) * mapScale);
    float es = 1.8f; CImage* img = nullptr;
    if (m_isFacingLeft) { if (m_ActionState == GruntAction::GR_HURT_FLY) img = &m_ImgHurtFly_L[m_CurrentFrame % 2]; else if (m_ActionState == GruntAction::GR_HURT_GROUND || m_State == EnemyState::ES_DEAD) img = &m_ImgHurtGround_L[m_CurrentFrame % 16]; else if (m_State == EnemyState::ES_FALL) img = &m_ImgFall_L[m_CurrentFrame % 13]; else if (m_State == EnemyState::ES_IDLE) img = &m_ImgIdle_L[m_CurrentFrame % 8]; else if (m_State == EnemyState::ES_WALK) img = &m_ImgWalk_L[m_CurrentFrame % 10]; }
    else { if (m_ActionState == GruntAction::GR_HURT_FLY) img = &m_ImgHurtFly_R[m_CurrentFrame % 2]; else if (m_ActionState == GruntAction::GR_HURT_GROUND || m_State == EnemyState::ES_DEAD) img = &m_ImgHurtGround_R[m_CurrentFrame % 16]; else if (m_State == EnemyState::ES_FALL) img = &m_ImgFall_R[m_CurrentFrame % 13]; else if (m_State == EnemyState::ES_IDLE) img = &m_ImgIdle_R[m_CurrentFrame % 8]; else if (m_State == EnemyState::ES_WALK) img = &m_ImgWalk_R[m_CurrentFrame % 10]; }
    if (img && !img->IsNull()) {
        int fw = (int)(img->GetWidth() * es * mapScale), fh = (int)(img->GetHeight() * es * mapScale);
        int fy = sy + (int)(m_colH * mapScale) - fh, dx = sx + (int)(m_colW * mapScale / 2) - (fw / 2);
        if (!isSlowMo && !m_isFacingLeft) { img->Draw(hdc, dx, fy, fw, fh); }
        else {
            if (img->IsDIBSection()) {
                void* bits = img->GetBits(); if (bits) {
                    Gdiplus::Bitmap b(img->GetWidth(), img->GetHeight(), img->GetPitch(), PixelFormat32bppARGB, (BYTE*)bits);
                    if (m_isFacingLeft) { g->ScaleTransform(-1.0f, 1.0f); g->TranslateTransform(-(float)(dx * 2 + fw), 0); }
                    if (isSlowMo) {
                        Gdiplus::ImageAttributes na; Gdiplus::ColorMatrix nm = {0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,1,0, 1,0,1,0,1}; na.SetColorMatrix(&nm);
                        int off = (int)(2 * mapScale);
                        g->DrawImage(&b, Gdiplus::Rect(dx - off, fy, fw, fh), 0, 0, img->GetWidth(), img->GetHeight(), Gdiplus::UnitPixel, &na);
                        g->DrawImage(&b, Gdiplus::Rect(dx + off, fy, fw, fh), 0, 0, img->GetWidth(), img->GetHeight(), Gdiplus::UnitPixel, &na);
                        g->DrawImage(&b, Gdiplus::Rect(dx, fy - off, fw, fh), 0, 0, img->GetWidth(), img->GetHeight(), Gdiplus::UnitPixel, &na);
                        g->DrawImage(&b, Gdiplus::Rect(dx, fy + off, fw, fh), 0, 0, img->GetWidth(), img->GetHeight(), Gdiplus::UnitPixel, &na);
                        Gdiplus::ImageAttributes ba; Gdiplus::ColorMatrix bm = {0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,1,0, 0,0,0,0,1}; ba.SetColorMatrix(&bm);
                        g->DrawImage(&b, Gdiplus::Rect(dx, fy, fw, fh), 0, 0, img->GetWidth(), img->GetHeight(), Gdiplus::UnitPixel, &ba);
                    } else g->DrawImage(&b, Gdiplus::Rect(dx, fy, fw, fh));
                    if (m_isFacingLeft) g->ResetTransform();
                }
            } else {
                img->Draw(hdc, dx, fy, fw, fh);
            }
        }
    }
    if (showDebugRect) RenderDebug(hdc, camX, camY, mapScale);
}

// Pomp
CImage Pomp::m_ImgIdle_R[8], Pomp::m_ImgIdle_L[8], Pomp::m_ImgWalk_R[10], Pomp::m_ImgWalk_L[10], Pomp::m_ImgAttack_R[6], Pomp::m_ImgAttack_L[6], Pomp::m_ImgBoxIdle_R[10], Pomp::m_ImgBoxIdle_L[10], Pomp::m_ImgBoxHit_R[14], Pomp::m_ImgBoxHit_L[14], Pomp::m_ImgTurn_R[6], Pomp::m_ImgTurn_L[6], Pomp::m_ImgFall_R[13], Pomp::m_ImgFall_L[13], Pomp::m_ImgHurtFly_R[2], Pomp::m_ImgHurtFly_L[2], Pomp::m_ImgHurtGround_R[15], Pomp::m_ImgHurtGround_L[15], Pomp::m_ImgRun_R[10], Pomp::m_ImgRun_L[10];
Pomp::Pomp(float x, float y) : Enemy(x, y, EnemyType::POMP) { m_ActionState = PompAction::PA_NONE; }
Pomp::~Pomp() {}
void Pomp::Reset() { Enemy::Reset(); m_ActionState = PompAction::PA_NONE; }
void Pomp::OnTakeDamage(float kvx, float kvy) { if (m_isImmortal) return; Enemy::OnTakeDamage(kvx, kvy); m_ActionState = PompAction::PA_HURT_FLY; }
void Pomp::Init() { if (!m_ImgIdle_R[0].IsNull()) return; TCHAR path[256]; for (int i = 0; i < 8; i++) { wsprintf(path, TEXT("assets/enemy/spr_pomp_idle/%d.png"), i); m_ImgIdle_R[i].Load(path); m_ImgIdle_L[i].Load(path); } for (int i = 0; i < 10; i++) { wsprintf(path, TEXT("assets/enemy/spr_pomp_walk/%d.png"), i); m_ImgWalk_R[i].Load(path); m_ImgWalk_L[i].Load(path); } for (int i = 0; i < 6; i++) { wsprintf(path, TEXT("assets/enemy/spr_pomp_attack/%d.png"), i); m_ImgAttack_R[i].Load(path); m_ImgAttack_L[i].Load(path); } for (int i = 0; i < 10; i++) { wsprintf(path, TEXT("assets/enemy/spr_pomp_box_idle/%d.png"), i); m_ImgBoxIdle_R[i].Load(path); m_ImgBoxIdle_L[i].Load(path); } for (int i = 0; i < 14; i++) { wsprintf(path, TEXT("assets/enemy/spr_pomp_box_hit/%d.png"), i); m_ImgBoxHit_R[i].Load(path); m_ImgBoxHit_L[i].Load(path); } for (int i = 0; i < 6; i++) { wsprintf(path, TEXT("assets/enemy/spr_pomp_turn/%d.png"), i); m_ImgTurn_R[i].Load(path); m_ImgTurn_L[i].Load(path); } for (int i = 0; i < 13; i++) { wsprintf(path, TEXT("assets/enemy/spr_pomp_fall/%d.png"), i); m_ImgFall_R[i].Load(path); m_ImgFall_L[i].Load(path); } for (int i = 0; i < 2; i++) { wsprintf(path, TEXT("assets/enemy/spr_pomp_hurtfly/%d.png"), i); m_ImgHurtFly_R[i].Load(path); m_ImgHurtFly_L[i].Load(path); } for (int i = 0; i < 15; i++) { wsprintf(path, TEXT("assets/enemy/spr_pomp_hurtground/%d.png"), i); m_ImgHurtGround_R[i].Load(path); m_ImgHurtGround_L[i].Load(path); } for (int i = 0; i < 10; i++) { wsprintf(path, TEXT("assets/enemy/spr_pomp_run/%d.png"), i); m_ImgRun_R[i].Load(path); m_ImgRun_L[i].Load(path); } }
void Pomp::Release() { for (int i = 0; i < 8; i++) { m_ImgIdle_R[i].Destroy(); m_ImgIdle_L[i].Destroy(); } for (int i = 0; i < 10; i++) { m_ImgWalk_R[i].Destroy(); m_ImgWalk_L[i].Destroy(); } for (int i = 0; i < 6; i++) { m_ImgAttack_R[i].Destroy(); m_ImgAttack_L[i].Destroy(); } for (int i = 0; i < 10; i++) { m_ImgBoxIdle_R[i].Destroy(); m_ImgBoxIdle_L[i].Destroy(); } for (int i = 0; i < 14; i++) { m_ImgBoxHit_R[i].Destroy(); m_ImgBoxHit_L[i].Destroy(); } for (int i = 0; i < 6; i++) { m_ImgTurn_R[i].Destroy(); m_ImgTurn_L[i].Destroy(); } for (int i = 0; i < 13; i++) { m_ImgFall_R[i].Destroy(); m_ImgFall_L[i].Destroy(); } for (int i = 0; i < 2; i++) { m_ImgHurtFly_R[i].Destroy(); m_ImgHurtFly_L[i].Destroy(); } for (int i = 0; i < 15; i++) { m_ImgHurtGround_R[i].Destroy(); m_ImgHurtGround_L[i].Destroy(); } for (int i = 0; i < 10; i++) { m_ImgRun_R[i].Destroy(); m_ImgRun_L[i].Destroy(); } }
void Pomp::Update(float ts, const Player& player) {
    CheckPlayerDetection(player); Enemy::Update(ts, player);
    if (!m_isAlive) { if (m_ActionState == PompAction::PA_HURT_FLY && m_vy == 0) { m_ActionState = PompAction::PA_HURT_GROUND; m_vx = 0; m_CurrentFrame = 0; } if (GetTickCount() - m_LastTime >= 100) { if (m_ActionState == PompAction::PA_HURT_GROUND) { if (m_CurrentFrame < 14) m_CurrentFrame++; } else m_CurrentFrame++; m_LastTime = GetTickCount(); } return; }
    if (m_isWaiting) { m_vx = 0.0f; m_State = EnemyState::ES_IDLE; if (GetTickCount() - m_patternTimer >= 1800) { m_isWaiting = false; m_patternTimer = GetTickCount(); m_walkDistance = 0.0f; m_isFacingLeft = !m_isFacingLeft; m_vx = m_isFacingLeft ? -2.2f : 2.2f; } }
    else { m_State = EnemyState::ES_WALK; float nx = m_x + m_vx * ts; if (!CheckMapCollision(nx, m_y, m_colW, m_colH)) { m_x = nx; m_walkDistance += (float)fabs(m_vx * ts); m_isFacingLeft = (m_vx < 0.0f); if (m_walkDistance >= m_patrolRange) { m_isWaiting = true; m_patternTimer = GetTickCount(); } } else { m_isWaiting = true; m_patternTimer = GetTickCount(); } }
    if (m_vy > 0.1f) m_State = EnemyState::ES_FALL; if (GetTickCount() - m_LastTime > 100) { m_CurrentFrame++; m_LastTime = GetTickCount(); }
}
void Pomp::Render(HDC hdc, Gdiplus::Graphics* g, float camX, float camY, float mapScale, bool showDebugRect, bool isSlowMo) {
    if (!m_isAlive && m_ActionState != PompAction::PA_HURT_FLY && m_ActionState != PompAction::PA_HURT_GROUND) return;
    int sx = (int)((m_x - camX) * mapScale), sy = (int)((m_y - camY) * mapScale);
    float es = 1.8f; CImage* img = nullptr;
    if (m_isFacingLeft) { if (m_ActionState == PompAction::PA_HURT_FLY) img = &m_ImgHurtFly_L[m_CurrentFrame % 2]; else if (m_ActionState == PompAction::PA_HURT_GROUND || m_State == EnemyState::ES_DEAD) img = &m_ImgHurtGround_L[m_CurrentFrame % 15]; else if (m_State == EnemyState::ES_FALL) img = &m_ImgFall_L[m_CurrentFrame % 13]; else if (m_State == EnemyState::ES_IDLE) img = &m_ImgIdle_L[m_CurrentFrame % 8]; else if (m_State == EnemyState::ES_WALK) img = &m_ImgWalk_L[m_CurrentFrame % 10]; }
    else { if (m_ActionState == PompAction::PA_HURT_FLY) img = &m_ImgHurtFly_R[m_CurrentFrame % 2]; else if (m_ActionState == PompAction::PA_HURT_GROUND || m_State == EnemyState::ES_DEAD) img = &m_ImgHurtGround_R[m_CurrentFrame % 15]; else if (m_State == EnemyState::ES_FALL) img = &m_ImgFall_R[m_CurrentFrame % 13]; else if (m_State == EnemyState::ES_IDLE) img = &m_ImgIdle_R[m_CurrentFrame % 8]; else if (m_State == EnemyState::ES_WALK) img = &m_ImgWalk_R[m_CurrentFrame % 10]; }
    if (img && !img->IsNull()) {
        int fw = (int)(img->GetWidth() * es * mapScale), fh = (int)(img->GetHeight() * es * mapScale);
        int fy = sy + (int)(m_colH * mapScale) - fh, dx = sx + (int)(m_colW * mapScale / 2) - (fw / 2);
        if (!isSlowMo && !m_isFacingLeft) { img->Draw(hdc, dx, fy, fw, fh); }
        else {
            if (img->IsDIBSection()) {
                void* bits = img->GetBits(); if (bits) {
                    Gdiplus::Bitmap b(img->GetWidth(), img->GetHeight(), img->GetPitch(), PixelFormat32bppARGB, (BYTE*)bits);
                    if (m_isFacingLeft) { g->ScaleTransform(-1.0f, 1.0f); g->TranslateTransform(-(float)(dx * 2 + fw), 0); }
                    if (isSlowMo) {
                        Gdiplus::ImageAttributes na; Gdiplus::ColorMatrix nm = {0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,1,0, 1,0,1,0,1}; na.SetColorMatrix(&nm);
                        int off = (int)(2 * mapScale);
                        g->DrawImage(&b, Gdiplus::Rect(dx - off, fy, fw, fh), 0, 0, img->GetWidth(), img->GetHeight(), Gdiplus::UnitPixel, &na);
                        g->DrawImage(&b, Gdiplus::Rect(dx + off, fy, fw, fh), 0, 0, img->GetWidth(), img->GetHeight(), Gdiplus::UnitPixel, &na);
                        g->DrawImage(&b, Gdiplus::Rect(dx, fy - off, fw, fh), 0, 0, img->GetWidth(), img->GetHeight(), Gdiplus::UnitPixel, &na);
                        g->DrawImage(&b, Gdiplus::Rect(dx, fy + off, fw, fh), 0, 0, img->GetWidth(), img->GetHeight(), Gdiplus::UnitPixel, &na);
                        Gdiplus::ImageAttributes ba; Gdiplus::ColorMatrix bm = {0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,1,0, 0,0,0,0,1}; ba.SetColorMatrix(&bm);
                        g->DrawImage(&b, Gdiplus::Rect(dx, fy, fw, fh), 0, 0, img->GetWidth(), img->GetHeight(), Gdiplus::UnitPixel, &ba);
                    } else g->DrawImage(&b, Gdiplus::Rect(dx, fy, fw, fh));
                    if (m_isFacingLeft) g->ResetTransform();
                }
            } else {
                img->Draw(hdc, dx, fy, fw, fh);
            }
        }
    }
    if (showDebugRect) RenderDebug(hdc, camX, camY, mapScale);
}

// ShieldCop
CImage ShieldCop::m_ImgIdle_R[6], ShieldCop::m_ImgIdle_L[6], ShieldCop::m_ImgWalk_R[10], ShieldCop::m_ImgWalk_L[10], ShieldCop::m_ImgRun_R[10], ShieldCop::m_ImgRun_L[10], ShieldCop::m_ImgTurn_R[8], ShieldCop::m_ImgTurn_L[8], ShieldCop::m_ImgAim_R[19], ShieldCop::m_ImgAim_L[19], ShieldCop::m_ImgBash_R[6], ShieldCop::m_ImgBash_L[6], ShieldCop::m_ImgKnockback_R[2], ShieldCop::m_ImgKnockback_L[2], ShieldCop::m_ImgTragedyDie_R[15], ShieldCop::m_ImgTragedyDie_L[15];
ShieldCop::ShieldCop(float x, float y) : Enemy(x, y, EnemyType::SHIELDCOP) { m_ActionState = ShieldCopAction::SA_NONE; }
ShieldCop::~ShieldCop() {}
void ShieldCop::Reset() { Enemy::Reset(); m_ActionState = ShieldCopAction::SA_NONE; }
void ShieldCop::OnTakeDamage(float kvx, float kvy) { if (m_isImmortal) return; Enemy::OnTakeDamage(kvx, kvy); m_ActionState = ShieldCopAction::SA_HURT_FLY; }
void ShieldCop::Init() { if (!m_ImgIdle_R[0].IsNull()) return; TCHAR path[256]; for (int i = 0; i < 6; i++) { wsprintf(path, TEXT("assets/enemy/spr_shieldcop_idle/%d.png"), i); m_ImgIdle_R[i].Load(path); m_ImgIdle_L[i].Load(path); } for (int i = 0; i < 10; i++) { wsprintf(path, TEXT("assets/enemy/spr_shieldcop_walk/%d.png"), i); m_ImgWalk_R[i].Load(path); m_ImgWalk_L[i].Load(path); } for (int i = 0; i < 10; i++) { wsprintf(path, TEXT("assets/enemy/spr_shieldcop_run/%d.png"), i); m_ImgRun_R[i].Load(path); m_ImgRun_L[i].Load(path); } for (int i = 0; i < 8; i++) { wsprintf(path, TEXT("assets/enemy/spr_shieldcop_turn/%d.png"), i); m_ImgTurn_R[i].Load(path); m_ImgTurn_L[i].Load(path); } for (int i = 0; i < 19; i++) { wsprintf(path, TEXT("assets/enemy/spr_shieldcop_aim/%d.png"), i); m_ImgAim_R[i].Load(path); m_ImgAim_L[i].Load(path); } for (int i = 0; i < 6; i++) { wsprintf(path, TEXT("assets/enemy/spr_shieldcop_bash/%d.png"), i); m_ImgBash_R[i].Load(path); m_ImgBash_L[i].Load(path); } for (int i = 0; i < 2; i++) { wsprintf(path, TEXT("assets/enemy/spr_shieldcop_knockback/%d.png"), i); m_ImgKnockback_R[i].Load(path); m_ImgKnockback_L[i].Load(path); } for (int i = 0; i < 15; i++) { wsprintf(path, TEXT("assets/enemy/spr_shieldcop_tragedy_die_1/%d.png"), i); m_ImgTragedyDie_R[i].Load(path); m_ImgTragedyDie_L[i].Load(path); } }
void ShieldCop::Release() { for (int i = 0; i < 6; i++) { m_ImgIdle_R[i].Destroy(); m_ImgIdle_L[i].Destroy(); } for (int i = 0; i < 10; i++) { m_ImgWalk_R[i].Destroy(); m_ImgWalk_L[i].Destroy(); } for (int i = 0; i < 10; i++) { m_ImgRun_R[i].Destroy(); m_ImgRun_L[i].Destroy(); } for (int i = 0; i < 8; i++) { m_ImgTurn_R[i].Destroy(); m_ImgTurn_L[i].Destroy(); } for (int i = 0; i < 19; i++) { m_ImgAim_R[i].Destroy(); m_ImgAim_L[i].Destroy(); } for (int i = 0; i < 6; i++) { m_ImgBash_R[i].Destroy(); m_ImgBash_L[i].Destroy(); } for (int i = 0; i < 2; i++) { m_ImgKnockback_R[i].Destroy(); m_ImgKnockback_L[i].Destroy(); } for (int i = 0; i < 15; i++) { m_ImgTragedyDie_R[i].Destroy(); m_ImgTragedyDie_L[i].Destroy(); } }
void ShieldCop::Update(float ts, const Player& player) {
    CheckPlayerDetection(player); Enemy::Update(ts, player);
    if (!m_isAlive) { if (m_ActionState == ShieldCopAction::SA_HURT_FLY && m_vy == 0) { m_ActionState = ShieldCopAction::SA_HURT_GROUND; m_vx = 0; m_CurrentFrame = 0; } if (GetTickCount() - m_LastTime >= 100) { if (m_ActionState == ShieldCopAction::SA_HURT_GROUND) { if (m_CurrentFrame < 14) m_CurrentFrame++; } else m_CurrentFrame++; m_LastTime = GetTickCount(); } return; }
    if (m_isWaiting) { m_vx = 0.0f; m_State = EnemyState::ES_IDLE; if (GetTickCount() - m_patternTimer >= 2200) { m_isWaiting = false; m_patternTimer = GetTickCount(); m_walkDistance = 0.0f; m_isFacingLeft = !m_isFacingLeft; m_vx = m_isFacingLeft ? -1.8f : 1.8f; } }
    else { m_State = EnemyState::ES_WALK; float nx = m_x + m_vx * ts; if (!CheckMapCollision(nx, m_y, m_colW, m_colH)) { m_x = nx; m_walkDistance += (float)fabs(m_vx * ts); m_isFacingLeft = (m_vx < 0.0f); if (m_walkDistance >= 140.0f) { m_isWaiting = true; m_patternTimer = GetTickCount(); } } else { m_isWaiting = true; m_patternTimer = GetTickCount(); } }
    if (m_vy > 0.1f) m_State = EnemyState::ES_FALL; if (GetTickCount() - m_LastTime > 100) { m_CurrentFrame++; m_LastTime = GetTickCount(); }
}
void ShieldCop::Render(HDC hdc, Gdiplus::Graphics* g, float camX, float camY, float mapScale, bool showDebugRect, bool isSlowMo) {
    if (!m_isAlive && m_ActionState != ShieldCopAction::SA_HURT_FLY && m_ActionState != ShieldCopAction::SA_HURT_GROUND) return;
    int sx = (int)((m_x - camX) * mapScale), sy = (int)((m_y - camY) * mapScale);
    float es = 1.8f; CImage* img = nullptr;
    if (m_isFacingLeft) { if (m_ActionState == ShieldCopAction::SA_HURT_FLY) img = &m_ImgKnockback_L[m_CurrentFrame % 2]; else if (m_ActionState == ShieldCopAction::SA_HURT_GROUND || m_State == EnemyState::ES_DEAD) img = &m_ImgTragedyDie_L[m_CurrentFrame % 15]; else if (m_State == EnemyState::ES_FALL) img = &m_ImgIdle_L[m_CurrentFrame % 6]; else if (m_State == EnemyState::ES_IDLE) img = &m_ImgIdle_L[m_CurrentFrame % 6]; else if (m_State == EnemyState::ES_WALK) img = &m_ImgWalk_L[m_CurrentFrame % 10]; }
    else { if (m_ActionState == ShieldCopAction::SA_HURT_FLY) img = &m_ImgKnockback_R[m_CurrentFrame % 2]; else if (m_ActionState == ShieldCopAction::SA_HURT_GROUND || m_State == EnemyState::ES_DEAD) img = &m_ImgTragedyDie_R[m_CurrentFrame % 15]; else if (m_State == EnemyState::ES_FALL) img = &m_ImgIdle_R[m_CurrentFrame % 6]; else if (m_State == EnemyState::ES_IDLE) img = &m_ImgIdle_R[m_CurrentFrame % 6]; else if (m_State == EnemyState::ES_WALK) img = &m_ImgWalk_R[m_CurrentFrame % 10]; }
    if (img && !img->IsNull()) {
        int fw = (int)(img->GetWidth() * es * mapScale), fh = (int)(img->GetHeight() * es * mapScale);
        int fy = sy + (int)(m_colH * mapScale) - fh, dx = sx + (int)(m_colW * mapScale / 2) - (fw / 2);
        if (!isSlowMo && !m_isFacingLeft) { img->Draw(hdc, dx, fy, fw, fh); }
        else {
            if (img->IsDIBSection()) {
                void* bits = img->GetBits(); if (bits) {
                    Gdiplus::Bitmap b(img->GetWidth(), img->GetHeight(), img->GetPitch(), PixelFormat32bppARGB, (BYTE*)bits);
                    if (m_isFacingLeft) { g->ScaleTransform(-1.0f, 1.0f); g->TranslateTransform(-(float)(dx * 2 + fw), 0); }
                    if (isSlowMo) {
                        Gdiplus::ImageAttributes na; Gdiplus::ColorMatrix nm = {0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,1,0, 1,0,1,0,1}; na.SetColorMatrix(&nm);
                        int off = (int)(2 * mapScale);
                        g->DrawImage(&b, Gdiplus::Rect(dx - off, fy, fw, fh), 0, 0, img->GetWidth(), img->GetHeight(), Gdiplus::UnitPixel, &na);
                        g->DrawImage(&b, Gdiplus::Rect(dx + off, fy, fw, fh), 0, 0, img->GetWidth(), img->GetHeight(), Gdiplus::UnitPixel, &na);
                        g->DrawImage(&b, Gdiplus::Rect(dx, fy - off, fw, fh), 0, 0, img->GetWidth(), img->GetHeight(), Gdiplus::UnitPixel, &na);
                        g->DrawImage(&b, Gdiplus::Rect(dx, fy + off, fw, fh), 0, 0, img->GetWidth(), img->GetHeight(), Gdiplus::UnitPixel, &na);
                        Gdiplus::ImageAttributes ba; Gdiplus::ColorMatrix bm = {0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,1,0, 0,0,0,0,1}; ba.SetColorMatrix(&bm);
                        g->DrawImage(&b, Gdiplus::Rect(dx, fy, fw, fh), 0, 0, img->GetWidth(), img->GetHeight(), Gdiplus::UnitPixel, &ba);
                    } else g->DrawImage(&b, Gdiplus::Rect(dx, fy, fw, fh));
                    if (m_isFacingLeft) g->ResetTransform();
                }
            } else {
                img->Draw(hdc, dx, fy, fw, fh);
            }
        }
    }
    if (showDebugRect) RenderDebug(hdc, camX, camY, mapScale);
}

